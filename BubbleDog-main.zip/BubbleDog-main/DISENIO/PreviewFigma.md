## Preview del diseño

### Preview en vivo
https://www.figma.com/file/IHDcvU6NX82XLp8waKcLWv/Untitled?node-id=0%3A1